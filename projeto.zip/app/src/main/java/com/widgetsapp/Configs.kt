package com.widgetsapp

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.Calendar

private const val INVALID = AppWidgetManager.INVALID_APPWIDGET_ID

private fun Activity.widgetId() = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, INVALID)

private fun Activity.done(id: Int) {
    setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
    finish()
}

private fun Activity.form(vararg views: View): View {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    val p = (24 * resources.displayMetrics.density).toInt()
    l.setPadding(p, p, p, p)
    views.forEach { l.addView(it) }
    return ScrollView(this).apply { addView(l) }
}

class NoteConfigActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        val id = widgetId()
        if (id == INVALID) { finish(); return }
        val prefs = getSharedPreferences("w", 0)
        val et = EditText(this).apply {
            setText(prefs.getString("note_$id", "")); hint = "Escreva sua nota"
            minLines = 5; gravity = Gravity.TOP
        }
        val btn = Button(this).apply {
            text = "Salvar"
            setOnClickListener {
                prefs.edit().putString("note_$id", et.text.toString()).apply()
                AppWidgetManager.getInstance(this@NoteConfigActivity).updateAppWidget(id, NoteWidget.build(this@NoteConfigActivity, id))
                done(id)
            }
        }
        setContentView(form(et, btn))
    }
}

class CountdownConfigActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        val id = widgetId()
        if (id == INVALID) { finish(); return }
        val prefs = getSharedPreferences("w", 0)
        val title = EditText(this).apply { hint = "Nome do evento"; setText(prefs.getString("cd_n_$id", "")) }
        val dp = DatePicker(this)
        val btn = Button(this).apply {
            text = "Salvar"
            setOnClickListener {
                val c = Calendar.getInstance().apply { set(dp.year, dp.month, dp.dayOfMonth, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
                prefs.edit().putLong("cd_t_$id", c.timeInMillis).putString("cd_n_$id", title.text.toString()).apply()
                AppWidgetManager.getInstance(this@CountdownConfigActivity).updateAppWidget(id, CountdownWidget.build(this@CountdownConfigActivity, id))
                done(id)
            }
        }
        setContentView(form(title, dp, btn))
    }
}

class PhotoConfigActivity : Activity() {
    private var id = INVALID
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        id = widgetId()
        if (id == INVALID) { finish(); return }
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data
        if (res != RESULT_OK || uri == null) { finish(); return }
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var s = 1
            while (bounds.outWidth / s > 900 || bounds.outHeight / s > 900) s *= 2
            var bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            }
            val rot = contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } ?: 0f
            if (bmp != null && rot != 0f) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
            }
            bmp?.let { b -> File(filesDir, "photo_$id.jpg").outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) } }
            AppWidgetManager.getInstance(this).updateAppWidget(id, PhotoWidget.build(this, id))
            done(id)
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao carregar a foto", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
