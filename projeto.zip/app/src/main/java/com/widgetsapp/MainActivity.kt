package com.widgetsapp

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = TextView(this)
        t.setPadding(48, 96, 48, 48)
        t.textSize = 18f
        t.text = "Widgets Tudo\n\nComo usar: segure um espaço vazio da tela inicial → Widgets → Widgets Tudo.\n\n" +
            "• Relógio digital\n• Relógio analógico\n• Data / Calendário\n• Relógio mundial\n• Bateria\n" +
            "• Frase do dia (toque para trocar)\n• Foto (toque para trocar)\n• Nota (toque para editar)\n• Contagem regressiva"
        setContentView(t)
    }
}
