package com.widgetsapp

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.os.BatteryManager
import android.widget.RemoteViews
import java.io.File
import java.util.Calendar

fun cfgIntent(c: Context, id: Int, cls: Class<*>): PendingIntent {
    val i = Intent(c, cls).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
    return PendingIntent.getActivity(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}

private fun prefs(c: Context) = c.getSharedPreferences("w", 0)

/** Widgets estáticos: os relógios (TextClock/AnalogClock) se atualizam sozinhos. */
open class SimpleWidget(private val layout: Int) : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, RemoteViews(c.packageName, layout)) }
    }
}
class ClockWidget : SimpleWidget(R.layout.w_clock)
class AnalogWidget : SimpleWidget(R.layout.w_analog)
class DateWidget : SimpleWidget(R.layout.w_date)
class WorldClockWidget : SimpleWidget(R.layout.w_world)

class BatteryWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = level * 100 / scale
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        ids.forEach {
            val v = RemoteViews(c.packageName, R.layout.w_battery)
            v.setTextViewText(R.id.pct, "$pct%")
            v.setProgressBar(R.id.bar, 100, pct, false)
            v.setTextViewText(R.id.st, if (charging) "⚡ Carregando" else "Bateria")
            m.updateAppWidget(it, v)
        }
    }
}

class QuoteWidget : AppWidgetProvider() {
    private val quotes = listOf(
        "Um passo de cada vez.", "Feito é melhor que perfeito.", "Hoje é um bom dia para começar.",
        "Quem não arrisca, não petisca.", "A persistência vence o talento.", "Respire fundo. Você consegue.",
        "O segredo é continuar.", "Pequenos hábitos, grandes resultados.", "Faça o seu melhor hoje.")
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach {
            val v = RemoteViews(c.packageName, R.layout.w_quote)
            v.setTextViewText(R.id.txt, quotes.random())
            val refresh = Intent(c, QuoteWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            v.setOnClickPendingIntent(R.id.root, PendingIntent.getBroadcast(c, 7, refresh, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            m.updateAppWidget(it, v)
        }
    }
}

class PhotoWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { m.updateAppWidget(it, build(c, it)) }
    override fun onDeleted(c: Context, ids: IntArray) = ids.forEach { File(c.filesDir, "photo_$it.jpg").delete() }
    companion object {
        fun build(c: Context, id: Int): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.w_photo)
            val f = File(c.filesDir, "photo_$id.jpg")
            if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { v.setImageViewBitmap(R.id.img, it) }
            v.setOnClickPendingIntent(R.id.root, cfgIntent(c, id, PhotoConfigActivity::class.java))
            return v
        }
    }
}

class NoteWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { m.updateAppWidget(it, build(c, it)) }
    companion object {
        fun build(c: Context, id: Int): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.w_note)
            val t = prefs(c).getString("note_$id", "") ?: ""
            v.setTextViewText(R.id.txt, if (t.isBlank()) "Toque para escrever uma nota" else t)
            v.setOnClickPendingIntent(R.id.root, cfgIntent(c, id, NoteConfigActivity::class.java))
            return v
        }
    }
}

class CountdownWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { m.updateAppWidget(it, build(c, it)) }
    companion object {
        fun build(c: Context, id: Int): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.w_countdown)
            val p = prefs(c)
            val target = p.getLong("cd_t_$id", 0L)
            val name = p.getString("cd_n_$id", "") ?: ""
            if (target == 0L) {
                v.setTextViewText(R.id.num, "?"); v.setTextViewText(R.id.lbl, "Toque para configurar")
            } else {
                val today = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val d = Math.round((target - today) / 86400000.0).toInt()
                when {
                    d > 0 -> { v.setTextViewText(R.id.num, "$d"); v.setTextViewText(R.id.lbl, "dias para $name") }
                    d == 0 -> { v.setTextViewText(R.id.num, "🎉"); v.setTextViewText(R.id.lbl, "Hoje: $name") }
                    else -> { v.setTextViewText(R.id.num, "${-d}"); v.setTextViewText(R.id.lbl, "dias desde $name") }
                }
            }
            v.setOnClickPendingIntent(R.id.root, cfgIntent(c, id, CountdownConfigActivity::class.java))
            return v
        }
    }
}
